# Simple PING test (Discord normally sends PING itself during verification).
# This is just an example; real Discord requests include signature headers.
curl -X POST -H "Content-Type: application/json" \
  -d '{"type":1}' https://yourdomain.com/interactions
