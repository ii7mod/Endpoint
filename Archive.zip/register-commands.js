/**
 * Simple script to register application commands (guild or global).
 * Usage:
 *   node register-commands.js --guild GUILD_ID
 *   node register-commands.js            # registers global (can take up to 1 hour)
 */

import { REST } from '@discordjs/rest';
import { Routes } from 'discord-api-types/v10';
import dotenv from 'dotenv';

dotenv.config();

const { BOT_TOKEN, APPLICATION_ID } = process.env;
if (!BOT_TOKEN || !APPLICATION_ID) {
  console.error('Set BOT_TOKEN and APPLICATION_ID in .env to register commands');
  process.exit(1);
}

const commands = [
  {
    name: 'ping',
    description: 'Replies with Pong!'
  },
  {
    name: 'announce',
    description: 'Test announce (demo)',
    options: [
      { name: 'message', description: 'Message to announce', type: 3, required: true },
      { name: 'channel_id', description: 'Channel ID (optional)', type: 3, required: false }
    ]
  }
];

const rest = new REST({ version: '10' }).setToken(BOT_TOKEN);

const args = process.argv.slice(2);
const guildIndex = args.indexOf('--guild');
const guildId = guildIndex !== -1 ? args[guildIndex + 1] : null;

(async () => {
  try {
    if (guildId) {
      console.log('Registering commands to guild', guildId);
      await rest.put(Routes.applicationGuildCommands(APPLICATION_ID, guildId), { body: commands });
      console.log('Registered guild commands.');
    } else {
      console.log('Registering global commands (may take up to 1 hour to appear)');
      await rest.put(Routes.applicationCommands(APPLICATION_ID), { body: commands });
      console.log('Registered global commands.');
    }
  } catch (err) {
    console.error('Error registering commands:', err);
  }
})();
