# Discord Interactions-only Endpoint (Express)

مشروع Node.js/Express بسيط يوفّر Interactions Endpoint جاهز لـDiscord (slash commands, buttons, etc.)
يتيح الرد على الأوامر بدون فتح Gateway — يعني التطبيق سيظهر في السيرفر بدون presence (بدون نقطة أونلاين).

## ما يحتويه المشروع
- `index.js` : سيرفر Express يستقبل POST `/interactions` ويستخدم `verifyKeyMiddleware` للتحقق من التوقيع.
- `.env.example` : مثال للمتغيرات البيئة المطلوبة.
- `package.json` : تعريف المشروع والاعتمادات.
- `register-commands.js` : سكربت لتسجيل أوامر التطبيق (global أو guild).
- `Dockerfile` و `docker-compose.yml`
- `test-interaction-curl.sh` : مثال curl لإرسال اختبار PING (غير موصى به للـ production).
- `logs/.gitkeep`

## إعداد سريع محلي
1. انسخ المشروع.
2. انسخ `.env.example` إلى `.env` واملأ القيم:
   ```
   PUBLIC_KEY=from_discord_developer_portal
   APPLICATION_ID=your_app_id
   BOT_TOKEN=your_bot_token   # مطلوب فقط لتسجيل الأوامر عبر REST
   PORT=3000
   ```
3. لتجربة محليًا استخدم ngrok أو أي tunnel HTTPS:
   ```
   ngrok http 3000
   ```
   وادخل الرابط في Discord Developer Portal > Application > General Information > Interactions Endpoint URL
   مثال: https://abcd1234.ngrok.io/interactions
4. ثبت الاعتمادات:
   ```
   npm install
   ```
5. (اختياري) سجّل الأوامر (guild for testing faster):
   ```
   node register-commands.js --guild GUILD_ID
   ```
6. شغّل السيرفر:
   ```
   npm run dev
   ```
7. جرب الأمر `/ping` داخل السيرفر.

## ملاحظات أمنية وتقنية
- تأكد أن `PUBLIC_KEY` لا يتم تسريبه. هذه القيمة موجودة في Developer Portal.
- الرد يجب أن يتم خلال 3 ثواني أو استخدم deferred responses.
- لا تستخدم user token أو self-bot.
- لتشغيل في الإنتاج استخدم HTTPS مباشر (Vercel, Render, Railway, DigitalOcean, etc.)

## ملفات مهمة
- `index.js` : نقطة الدخول.
- `register-commands.js` : لتسجيل أوامر `ping` و `announce`.
