import express from 'express';
import { verifyKeyMiddleware } from 'discord-interactions';
import dotenv from 'dotenv';
import helmet from 'helmet';
import morgan from 'morgan';
import winston from 'winston';

dotenv.config();
const { PUBLIC_KEY, PORT = 3000 } = process.env;
if (!PUBLIC_KEY) {
  console.error('Missing PUBLIC_KEY in .env');
  process.exit(1);
}

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.printf(({timestamp, level, message}) => `${timestamp} [${level}] ${message}`)
  ),
  transports: [
    new winston.transports.File({ filename: 'logs/app.log' }),
    new winston.transports.Console()
  ]
});

const app = express();
app.use(helmet());
app.use(morgan('combined', { stream: { write: msg => logger.info(msg.trim()) } }));

// Discord requires raw body to verify signature => use express.raw for the endpoint
app.post('/interactions', express.raw({ type: 'application/json' }), verifyKeyMiddleware(PUBLIC_KEY), (req, res) => {
  try {
    const interaction = JSON.parse(req.body.toString('utf8'));

    // PING
    if (interaction.type === 1) {
      return res.status(200).json({ type: 1 });
    }

    // APPLICATION_COMMAND
    if (interaction.type === 2) {
      const name = interaction.data.name;
      if (name === 'ping') {
        return res.status(200).json({
          type: 4,
          data: { content: 'Pong! ⚡️ (from interactions endpoint)' }
        });
      }

      if (name === 'announce') {
        const options = interaction.data.options || [];
        const messageOpt = options.find(o => o.name === 'message');
        const channelOpt = options.find(o => o.name === 'channel_id');

        const content = messageOpt ? messageOpt.value : 'No message provided';
        const channelId = channelOpt ? channelOpt.value : null;

        // If you want to send message to channel use a configured webhook or bot REST call.
        // For simplicity: reply acknowledging the announce
        return res.status(200).json({
          type: 4,
          data: { content: `Announce received. Message: ${content}${channelId ? ' to channel ' + channelId : ''}` }
        });
      }
    }

    return res.status(400).end();
  } catch (err) {
    logger.error('Handler error: ' + err.message);
    return res.status(500).json({ error: err.message });
  }
});

app.get('/', (req, res) => res.send('Discord Interactions Endpoint is running'));

app.listen(PORT, () => {
  logger.info(`Listening on port ${PORT}`);
  console.log(`Listening on port ${PORT}`);
});
